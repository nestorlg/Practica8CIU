// noprotect

var x;
var y;
var z;
var opt;
var ventana;
var forma_lapiz;
var tam;

function setup () {
  createCanvas(512,512);
  x = 0;
  y = 0;
  z = 0;
  opt = 0;
  ventana = 1;
  console.log("Modo de dibujo. Mantenga pulsado el ratón para trazar su dibujo. Ajuste el tamaño del pincel con la rueda del ratón (desplácelo hacia arriba para un grosor amplio y hacia abajo para un grosor estrecho. Puede alternar entre modo círculo, modo cuadrado y modo borrador con las teclas ARRIBA y ABAJO. Para elegir el color, pulse la tecla IZQUIERDA o DERECHA.");
  tam = 5;
  forma_lapiz = 0;
  background(255);
}

function draw () {
  if (ventana == 0) {
    switch (forma_lapiz) {
      case 0:   if (mouseIsPressed) {
                  fill(x,y,z);
                  noStroke();
                  ellipse(mouseX,mouseY,tam,tam);
                }
                break;
      case 1:   if (mouseIsPressed) {
                  fill(x,y,z);
                  noStroke();
                  rect(mouseX,mouseY,tam,tam);
                }
                break;
      case 2:   if (mouseIsPressed) {
                  fill(255);
                  noStroke();
                  ellipse(mouseX,mouseY,tam,tam);
                }
                break;
      default:  
                break;
    }
  } else {
    push();
    scale(0.2);
	for (var i = 0;i < 256;i++) {
      fill(i,0,0);
  	  noStroke();
      rect(2*i,0,2,128);
	}
    for (var i = 0;i < 256;i++) {
	  fill(0,i,0);
	  noStroke();
	  rect(2*i,128,2,128);
	}
    for (var i = 0;i < 256;i++) {
	  fill(0,0,i);
	  noStroke();
	  rect(2*i,256,2,128);
    }
	
    switch (opt) {
	case 0:	fill(255);
			rect(2*x,0,2,128);
			break;
	case 1:	fill(255);
			rect(2*y,128,2,128);
			break;
	case 2:	fill(255);
			rect(2*z,256,2,128);
			break;
	default:
			break;
    }
	
	for (var i = 0;i < 256;i++) {
	  fill(x,y,z);
	  noStroke();
	  rect(2*i,384,2,128);
	}
    if (keyIsPressed) {
      if (keyCode == LEFT_ARROW) {
        switch (opt) {
          case 0: x--;
                  if (x <= 0) x = 0;
                  break;
          case 1: y--;
                  if (y <= 0) y = 0;
                  break;
          case 2: z--;
                  if (z <= 0) z = 0;
                  break;
          }
        } else {
          if (keyCode == RIGHT_ARROW) {
            switch (opt) {
              case 0: x++;
                      if (x >= 255) x = 255;
                      break;
              case 1: y++;
                      if (y >= 255) y = 255;
                      break;
              case 2: z++;
                      if (z >= 255) z = 255;
                      break;
          }
        }
      }
    }
    pop();
  }
}

function keyPressed() {
  if (keyCode == UP_ARROW) {
	if (ventana == 0) {
      forma_lapiz--;
    } else {
      opt--;
    }
  } else {
	if (keyCode == DOWN_ARROW) {
	  if (ventana == 0) {
        forma_lapiz++;
      } else {
        opt++;
      }
	}
  }
  if (opt >= 3) opt = 0;
  if (opt <= -1) opt = 2;
  if (forma_lapiz >= 3) forma_lapiz = 0;
  if (forma_lapiz <= -1) forma_lapiz = 2;
  if (ventana == 0 && (keyCode == LEFT_ARROW || keyCode == RIGHT_ARROW)) {
    console.log("Cambiando a elección de colores. Pulse las flechas ARRIBA y ABAjo para elegir entre rojo, verde y azul, y ajuste su nivel deseado con las flechas IZQUIERDA y DERECHA; de ese modo, podrá obtener su color deseado. Para volver al modo dibujo, haga click con el ratón.");
    ventana = 1;
  }
  switch (forma_lapiz) {
    case 0:   console.log("Modo círculo");
              break;
    case 1:   console.log("Modo cuadrado");
              break;
    case 2:   console.log("Modo borrador");
              break;
    default:  break;
  }
}

function mousePressed() {
  if (ventana == 1) {
    ventana = 0;
    console.log("Modo de dibujo. Mantenga pulsado el ratón para trazar su dibujo. Ajuste el tamaño del pincel con la rueda del ratón (desplácelo hacia arriba para un grosor amplio y hacia abajo para un grosor estrecho. Puede alternar entre modo círculo, modo cuadrado y modo borrador con las teclas ARRIBA y ABAJO. Para elegir el color, pulse la tecla IZQUIERDA o DERECHA.");
  }
}

function mouseWheel(event) {
  tam -= event.deltaY;
  if (tam <= 0) tam = 1; 
  if (tam > width/4.0) tam = width/4.0;
}